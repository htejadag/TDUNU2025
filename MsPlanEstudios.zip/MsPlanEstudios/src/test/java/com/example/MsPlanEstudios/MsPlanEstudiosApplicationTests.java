package com.example.MsPlanEstudios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsPlanEstudiosApplicationTests {

	@Test
	void contextLoads() {
	}

}
