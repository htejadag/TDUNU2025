package com.example.MsPlanEstudios;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsPlanEstudiosApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsPlanEstudiosApplication.class, args);
	}

}
