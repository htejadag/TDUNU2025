package com.example.MsPlanEstudios.model.request;

public class PlanEstudiosPrerequisitoRequest {
    private Integer idPlanEstudioDetalle;
    private Integer idCursoPrerequisito;
}
